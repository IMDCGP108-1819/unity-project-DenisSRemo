﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class meteorite : MonoBehaviour {

    public float speed;
    public int collisions;
    private float StartTime;
    public float LifeTime = 50f;
    private Rigidbody2D rigidBody;
    public Vector3 StartingPosition;
    void Start () {
        rigidBody = GetComponent<Rigidbody2D>();
        StartingPosition = gameObject.transform.position;
    }
	
	//movement of the meteorite
	void Update () {
        transform.position += -transform.right * speed;

        if (Time.time >= StartTime + LifeTime)
        {
            gameObject.SetActive(false);
            gameObject.transform.position = StartingPosition;
            gameObject.SetActive(true);
            StartTime = Time.time;
            if (collisions == 2 || collisions==3)
                collisions = 0;
        }
        speed = speed + speed /100000;
	}
    //when the meteorite hits the player a hearth is gone
    void OnTriggerEnter2D(Collider2D col)
    {
        collisions++;

        if ( collisions ==3 )
            GameControl.health -= 1;

    }
}
