﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player : MonoBehaviour {
    public float speed;
    public float score;
    public float AddForce;
    public float startTime;
    private Rigidbody2D rb;
    private bool facingRight;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        facingRight = true;
        startTime = Time.time;
    }

    void Update()
    {
        if(Time.time-startTime>=60 && Input.GetKey(KeyCode.LeftShift))
        {
            startTime = Time.time;
        }
        else
        {
            startTime = Time.time;
        }

    }

    //Player's movement
    void FixedUpdate()
    {
        float Horizontal = Input.GetAxis("Horizontal") * speed;
        float Vertical = Input.GetAxis("Vertical") * speed;
        Vector3 vel = rb.velocity;
        vel.x = Horizontal;
        vel.y = Vertical;
        rb.velocity = vel;
        Flip(Horizontal);
    }
    //this makes the player turn left or right so that it faces the right direction
        private void Flip(float Horizontal)
        {
            if(Horizontal>0 && !facingRight || Horizontal<0 && facingRight)
            {
                facingRight = !facingRight;
                Vector3 theScale = transform.localScale;
                theScale.x *= -1;
                transform.localScale = theScale;

            }
        }

    
   


}