﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameControlScript : MonoBehaviour {

    public GameObject Heart1, Heart2, Heart3, Heart4;
    public static int health;
	void Start ()
    {
        health = 4;
        Heart1.gameobject.SetActive(true);
        Heart2.gameobject.SetActive(true);
        Heart3.gameobject.SetActive(true);
        Heart4.gameobject.SetActive(true);
        gameOver.gameObject.SetActive(false);
    }
	
	
	void Update ()
    {
        if (health > 4)
            health = 4;
        switch (health){
            case 4:
                Heart1.gameobject.SetActive(true);
                Heart2.gameobject.SetActive(true);
                Heart3.gameobject.SetActive(true);
                Heart4.gameobject.SetActive(true);
                break;
            case 3:
                Heart1.gameobject.SetActive(true);
                Heart2.gameobject.SetActive(true);
                Heart3.gameobject.SetActive(true);
                Heart4.gameobject.SetActive(false);
                break;
            case 2:
                Heart1.gameobject.SetActive(true);
                Heart2.gameobject.SetActive(true);
                Heart3.gameobject.SetActive(false);
                Heart4.gameobject.SetActive(false);
                break;
            case 1:
                Heart1.gameobject.SetActive(true);
                Heart2.gameobject.SetActive(false);
                Heart3.gameobject.SetActive(false);
                Heart4.gameobject.SetActive(false);
                break;
            case 0:
                Heart1.gameobject.SetActive(false);
                Heart2.gameobject.SetActive(false);
                Heart3.gameobject.SetActive(false);
                Heart4.gameobject.SetActive(false);
                gameOver.gameObject.SetActive(true);
                Time.timecale = 0;
                break;
        }
	}
}
